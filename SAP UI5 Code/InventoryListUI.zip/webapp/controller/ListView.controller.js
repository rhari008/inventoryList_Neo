sap.ui.define([
	'jquery.sap.global',
   "sap/ui/core/mvc/Controller",
   "sap/m/MessageToast",
   'sap/ui/model/json/JSONModel',
   "./Formatter"
], function (jQuery, Controller, MessageToast, JSONModel, Formatter) {
   "use strict";
   return Controller.extend("sap.sample.wt.controller.ListView", {
   	  Formatter: Formatter,
      onInit : function () {
      	var context = this;
		jQuery.getJSON("/inventory").done(function(sample){
			//Just to ensure that initialization is called prior 
			var test = sample;
		});
		//Get the JSON data
		jQuery.getJSON("/inventory/api/v1/inventorydata").done(function(mData){
			MessageToast.show(mData);
			var jsonMsg = JSON.stringify(mData);
			jsonMsg = '{"Inventory": ' + jsonMsg + '}';
		    var localModel = new JSONModel(JSON.parse(jsonMsg));  
		    context.getView().setModel(localModel);
		});
	},
      
     // simulate a refresh of the date that lasts 2 secs
		handleRefresh : function (evt) {
			var that = this;
			setTimeout(function () {
				that.getView().byId("pullToRefresh").hide();
				that.loadPage(that);
			}, 1000);
		},
		
		//Load page function
		loadPage : function(ctx){
				jQuery.getJSON("/inventory").done(function(sample){
						//Get the JSON data
		      		jQuery.getJSON("/inventory/api/v1/inventorydata").done(function(mData){
		      			MessageToast.show(mData);
		      			var jsonMsg = JSON.stringify(mData);
		      			jsonMsg = '{"Inventory": ' + jsonMsg + '}';
		          	    var localModel = new JSONModel(JSON.parse(jsonMsg));  
		      	        ctx.getView().setModel(localModel);
		      		});
					
				});
		}
		
   });
});