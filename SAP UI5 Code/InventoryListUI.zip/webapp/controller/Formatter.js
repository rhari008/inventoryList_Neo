sap.ui.define(function() {
	"use strict";

	var Formatter = {

		stockState :  function (fValue) {
			try {
				fValue = parseInt(fValue);
				if (fValue < 0) {
					return "None";
				} else if (fValue < 50) {
					return "Error";
				} else if (fValue < 100) {
					return "Warning";
				} else {
					return "Success";
				}
			} catch (err) {
				return "None";
			}
		}
	};

	return Formatter;

}, /* bExport= */ true);
